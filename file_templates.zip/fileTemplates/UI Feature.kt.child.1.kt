#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME} #end


import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModel
import dev.zacsweers.metro.AppScope
import dev.zacsweers.metro.ContributesIntoMap
import dev.zacsweers.metro.Inject
import dev.zacsweers.metro.binding
import dev.zacsweers.metrox.viewmodel.ViewModelKey
import io.baselines.ui.viewmodel.Mvvm
import io.baselines.ui.viewmodel.createEventSink

@Inject
@ContributesIntoMap(AppScope::class, binding<ViewModel>())
@ViewModelKey(${NAME}ViewModel::class)
class ${NAME}ViewModel : ViewModel(), Mvvm<${NAME}UiEvent, ${NAME}UiState> {

    private val eventSink = createEventSink(::handleEvent)

    @Composable
    override fun state(): ${NAME}UiState {
        return ${NAME}UiState(
            eventSink = eventSink,
        )
    }
    
    private fun handleEvent(event: ${NAME}UiEvent) {
        /* no-op */
    }
}
