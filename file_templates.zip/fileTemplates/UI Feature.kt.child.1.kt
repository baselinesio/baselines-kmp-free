#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME} #end


import androidx.compose.runtime.Composable
import io.baselines.ui.viewmodel.BaselineViewModel
import me.tatarka.inject.annotations.Inject

@Inject
class ${NAME}ViewModel : BaselineViewModel<${NAME}UiEvent, ${NAME}UiState>() {

    @Composable
    override fun state(): ${NAME}UiState {
        return ${NAME}UiState { event ->
            // Todo: TBD
        }
    }
}
