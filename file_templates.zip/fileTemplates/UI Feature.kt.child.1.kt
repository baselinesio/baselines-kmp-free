#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME} #end


import androidx.compose.runtime.Composable
import dev.zacsweers.metro.AppScope
import dev.zacsweers.metro.ContributesIntoMap
import dev.zacsweers.metro.Inject
import dev.zacsweers.metro.binding
import dev.zacsweers.metrox.viewmodel.ViewModelKey
import io.baselines.ui.viewmodel.BaselineViewModel

@Inject
@ContributesIntoMap(
    scope = AppScope::class,
    binding = binding<ViewModel>(),
)
@ViewModelKey(${NAME}ViewModel::class)
class ${NAME}ViewModel : BaselineViewModel<${NAME}UiEvent, ${NAME}UiState>() {

    @Composable
    override fun state(): ${NAME}UiState {
        return ${NAME}UiState { event ->
            /* no-op */
        }
    }
}
