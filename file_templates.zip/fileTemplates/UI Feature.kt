#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME} #end


import androidx.navigation.compose.composable
import io.baselines.toolkit.di.UiScope
import io.baselines.ui.viewmodel.viewModel
import me.tatarka.inject.annotations.IntoSet
import me.tatarka.inject.annotations.Provides
import software.amazon.lastmile.kotlin.inject.anvil.ContributesTo

@ContributesTo(UiScope::class)
interface ${NAME}UiModule {

    @Provides
    @IntoSet
    fun provide${NAME}NavGraphEntry(
        vmFactory: () -> ${NAME}ViewModel,
    ): NavGraphEntry {
        return NavGraphEntry {
            composable<AppNavRoutes.${NAME}> {
                ${NAME}Route(viewModel(vmFactory))
            }
        }
    }
}
