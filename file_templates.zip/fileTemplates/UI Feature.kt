#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME} #end


import androidx.navigation.compose.composable
import dev.zacsweers.metro.ContributesTo
import dev.zacsweers.metro.IntoSet
import dev.zacsweers.metro.Provides
import dev.zacsweers.metrox.viewmodel.metroViewModel
import io.baselines.toolkit.di.UiScope

@ContributesTo(UiScope::class)
interface ${NAME}UiModule {

    @Provides
    @IntoSet
    fun provide${NAME}NavGraphEntry(): NavGraphEntry {
        return NavGraphEntry {
            composable<AppNavRoutes.${NAME}> {
                ${NAME}Route(metroViewModel())
            }
        }
    }
}
