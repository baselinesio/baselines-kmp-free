#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME} #end


import io.baselines.ui.viewmodel.UiEvent

sealed interface ${NAME}UiEvent : UiEvent
