#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME} #end


import androidx.compose.runtime.Composable

@Composable
fun ${NAME}Route(viewModel: ${NAME}ViewModel) {
    val state = viewModel.state()
    val eventSink = state.eventSink
    ${NAME}Screen()
}
