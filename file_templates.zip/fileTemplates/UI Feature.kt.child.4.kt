#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME} #end


import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun ${NAME}Screen() {
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Text("[ ${NAME} ]")
    }
}

@Preview
@Composable
private fun Preview${NAME}Screen() {
    AppTheme {
        ${NAME}Screen()
    }
}
