#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME} #end


import androidx.compose.runtime.Composable
import org.jetbrains.compose.ui.tooling.preview.Preview

@Composable
fun ${NAME}Screen() {

}

@Preview
@Composable
private fun Preview${NAME}Screen() {
    AppTheme {
        ${NAME}Screen()
    }
}
