#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME} #end


import androidx.compose.runtime.Immutable
import io.baselines.ui.viewmodel.UiState

@Immutable
data class ${NAME}UiState(
    override val eventSink: (${NAME}UiEvent) -> Unit,
) : UiState<${NAME}UiEvent>